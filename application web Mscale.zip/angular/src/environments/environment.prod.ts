export const environment = {
  production: true,
  appName: 'My Angular Project',
  apiBaseUrl: 'api/'
};
