export class DatatablePage {
  count: number;
  pageSize: number;
  limit: number;
  offset: number;
}
