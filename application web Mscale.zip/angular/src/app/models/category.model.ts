export class Category {
  id: string;
  key: string;
  name: string;
  sequence: string;
}
