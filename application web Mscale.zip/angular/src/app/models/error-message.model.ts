export class ErrorMessage {
  field: string;
  message: string;
}
