import { Options } from './option.model';

export const USER_STATUS: Options = [
  { value: 'male', label: 'Homme' },
  { value: 'female', label: 'Femme' },
];

export class User {
  id: string;
  index: string;
  picture: string;
  sex: string;
  name: {
    first: string;
    last: string;
  };
  password: string;
  birthDate: Date;
  email: string;
  phone: string;
  address: string;
  isAdmin: boolean;
}
