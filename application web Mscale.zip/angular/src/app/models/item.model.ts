export class Item {
  value: any;
  name: string;
}

export type Items = Item[];
