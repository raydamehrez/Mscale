export class MeasureSearch {
  measure?: string;
  email?: string;
  status?: string;
  createTimeRange?: string;
}
