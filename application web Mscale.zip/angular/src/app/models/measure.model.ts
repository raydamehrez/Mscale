export class Measure {
  id: string;
  index: string;
  weight: string;
  bmi: string;
  date: Date;
  height: string;
  fat: string;
  bones: string;
  water: string;
  bmr: string;
}
