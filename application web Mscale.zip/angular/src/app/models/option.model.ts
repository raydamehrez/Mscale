export class Option {
  value: any;
  label: string;
}

export type Options = Option[];
