import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { SortPropDir } from '@swimlane/ngx-datatable';
import { BehaviorSubject, Observable, Subscription } from 'rxjs/Rx';

import { convertSortToString } from 'app/common';
import { Measure, MeasureSearch, DatatablePage } from 'app/models';
import { MeasureService } from 'app/services/measure.service';

@Injectable()
export class MeasureStore {
  readonly loading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  readonly items: BehaviorSubject<Measure[]> = new BehaviorSubject([]);
  readonly page: BehaviorSubject<DatatablePage>;
  readonly sorts: BehaviorSubject<SortPropDir[]> = new BehaviorSubject([]);
  readonly search: BehaviorSubject<MeasureSearch> = new BehaviorSubject(new MeasureSearch());

  constructor(private measureService: MeasureService) {
    const page = new DatatablePage();
    page.count = 0;
    page.pageSize = 10;
    page.limit = page.pageSize;
    page.offset = 0;
    this.page = new BehaviorSubject(page);
  }

  fetchData(params: HttpParams = this.buildHttpParams()): Subscription {
    this.loading.next(true);
    return this.measureService
      .getAll(params)
      .finally(() => {
        this.loading.next(false);
      })
      .subscribe((res: any) => {
        console.log(res);
        this.items.next(res as Measure[]);
      });
  }

  buildHttpParams(): HttpParams {
    const page: number = this.page.value.offset + 1;
    const perPage: number = this.page.value.limit;
    const sort: SortPropDir | undefined = this.sorts.value[0];
    const searchModel: MeasureSearch = this.search.value;

    let params = new HttpParams();

    params = params.set('page', String(page)).set('per-page', String(perPage));

    if (sort) {
      params = params.set('sort', convertSortToString(sort));
    }

    Object.keys(searchModel).forEach((key: string) => {
      const value = searchModel[key];
      if (value) {
        params = params.set(`MeasureSearch[${key}]`, String(value));
      }
    });

    return params;
  }

  create(model: Measure): Observable<any> {
    return this.measureService.post(model);
  }

  update(model: Measure): Observable<any> {
    return this.measureService.put(model);
  }

  delete(model: Measure): Observable<any> {
    return this.measureService.delete(model.id);
  }
}
