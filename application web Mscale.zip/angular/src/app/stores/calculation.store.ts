import { Injectable, Inject } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { BehaviorSubject, Subscription } from 'rxjs/Rx';
import * as moment from 'moment';

import {
  convertObjectToItems,
  concatTimesFormatByISOString,
  TIME_RANGE_SEPARATOR,
} from 'app/common';
import { Items } from 'app/models';
import { CalculationService } from 'app/services/calculation.service';

@Injectable()
export class CalculationStore {
  readonly dailyPostsLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  readonly dailyPosts: BehaviorSubject<Items> = new BehaviorSubject([]);

  constructor(
    private calculationService: CalculationService,
    @Inject(TIME_RANGE_SEPARATOR) private timeRangeSeparator: string,
  ) {}

  fetchDailyPosts(params: HttpParams = this.buildHttpParams()): any {
    /*this.dailyPostsLoading.next(true);
    return this.calculationService
      .dailyPosts(params)
      .finally(() => {
        this.dailyPostsLoading.next(false);
      })
      .subscribe((res: any) => {*/

    let res = {
      status: 'success',
      data: {
        '2019-09-06': 0,
        '2019-09-07': 0,
        '2019-09-08': 0,
        '2019-09-09': 0,
        '2019-09-10': 0,
        '2019-09-11': 0,
        '2019-09-12': 0,
        '2019-09-13': 0,
        '2019-09-14': 0,
        '2019-09-15': 0,
        '2019-09-16': 0,
        '2019-09-17': 0,
        '2019-09-18': 0,
        '2019-09-19': 0,
        '2019-09-20': 0,
        '2019-09-21': 0,
        '2019-09-22': 0,
        '2019-09-23': 0,
        '2019-09-24': 0,
        '2019-09-25': 0,
        '2019-09-26': 0,
        '2019-09-27': 0,
        '2019-09-28': 0,
        '2019-09-29': 0,
        '2019-09-30': 0,
        '2019-10-01': 0,
        '2019-10-02': 0,
        '2019-10-03': 0,
        '2019-10-04': 0,
        '2019-10-05': 0,
        '2019-10-06': 0,
        '2019-10-08': 0,
      },
    };
    let data = {};
    let rand = Math.random() * 12 + 18;
    Object.keys(res.data).forEach(key => {
      rand += Math.random() > 0.5 ? Math.random() : -Math.random();
      data[key] = rand;
    });
    this.dailyPosts.next(convertObjectToItems(data));
    // });
  }

  buildHttpParams(): HttpParams {
    let params = new HttpParams();

    params = params.set(
      'Calculator[timeRange]',
      concatTimesFormatByISOString(
        moment()
          .subtract(1, 'month')
          .startOf('day'),
        moment(),
        this.timeRangeSeparator,
      ),
    );

    return params;
  }
}
