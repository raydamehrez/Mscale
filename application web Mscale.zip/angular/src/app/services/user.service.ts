import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

import { User } from 'app/models';
import { environment } from 'environments/environment';

@Injectable()
export class UserService {
  constructor(private httpClient: HttpClient) {}

  getAll(params: HttpParams | null = null): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}users`, { params });
  }

  get(id: number | string): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}users/${id}`);
  }

  post(model: User): Observable<any> {
    return this.httpClient.post(`${environment.apiBaseUrl}users`, {
      ...model,
      picture: `https://randomuser.me/api/portraits/${
        Math.random() > 0.5 ? 'women' : 'men'
      }/${Math.floor(Math.random() * 50) + 1}.jpg`,
    });
  }

  put(model: User): Observable<any> {
    return this.httpClient.put(`${environment.apiBaseUrl}users/${model.id}`, { User: model });
  }

  delete(id: number | string): Observable<any> {
    return this.httpClient.delete(`${environment.apiBaseUrl}users/${id}`);
  }

  postAvatar(id: number | string, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(`${environment.apiBaseUrl}users/${id}/avatar`, formData);
  }
}
