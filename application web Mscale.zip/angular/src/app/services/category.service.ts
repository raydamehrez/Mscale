import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

import { Category } from 'app/models';
import { environment } from 'environments/environment';

@Injectable()
export class CategoryService {

  constructor(
    private httpClient: HttpClient
  ) { }

  getAll(params: HttpParams | null = null): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}categories`, { params });
  }

  get(id: number | string): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}category/${id}`);
  }

  post(model: Category): Observable<any> {
    return this.httpClient.post(`${environment.apiBaseUrl}category`, { Category: model });
  }

  put(model: Category): Observable<any> {
    return this.httpClient.put(`${environment.apiBaseUrl}category/${model.id}`, { Category: model });
  }

  delete(id: number | string): Observable<any> {
    return this.httpClient.delete(`${environment.apiBaseUrl}category/${id}`);
  }
}
