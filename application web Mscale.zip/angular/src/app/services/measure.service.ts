import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

import { Measure } from 'app/models';
import { environment } from 'environments/environment';

@Injectable()
export class MeasureService {
  constructor(private httpClient: HttpClient) {}

  getAll(params: HttpParams | null = null): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}measures`, { params });
  }

  get(id: number | string): Observable<any> {
    return this.httpClient.get(`${environment.apiBaseUrl}measures/${id}`);
  }

  post(model: Measure): Observable<any> {
    return this.httpClient.post(`${environment.apiBaseUrl}measures`, {
      ...model,
    });
  }

  put(model: Measure): Observable<any> {
    return this.httpClient.put(`${environment.apiBaseUrl}measures/${model.id}`, { Measure: model });
  }

  delete(id: number | string): Observable<any> {
    return this.httpClient.delete(`${environment.apiBaseUrl}measures/${id}`);
  }

  postAvatar(id: number | string, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(`${environment.apiBaseUrl}measures/${id}/avatar`, formData);
  }
}
