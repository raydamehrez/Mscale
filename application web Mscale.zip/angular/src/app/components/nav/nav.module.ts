import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatIconModule, MatListModule } from '@angular/material';
import { CommonModule } from '@angular/common';

import { NavComponent } from './nav.component';

@NgModule({
  declarations: [NavComponent],
  imports: [RouterModule, FlexLayoutModule, MatIconModule, MatListModule, CommonModule],
  exports: [NavComponent],
})
export class NavModule {}
