import { Component, EventEmitter, Output } from '@angular/core';
import { AuthStore, UserStore } from '../../stores';
import { User } from '../../models';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
})
export class NavComponent {
  modelSubscription: Subscription;
  model: User;

  @Output() routerClick: EventEmitter<any> = new EventEmitter();

  constructor(private authStore: AuthStore) {
    this.modelSubscription = authStore.user.subscribe((item: User) => {
      this.model = item;
    });
  }
  onRouterClick(): void {
    this.routerClick.emit();
  }
}
