import { Component, OnInit, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { AuthStore, CalculationStore } from 'app/stores';
import { User } from '../../models';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss'],
})
export class OverviewComponent implements OnInit, OnDestroy {
  readonly dailyPostsLoading: BehaviorSubject<boolean>;
  dailyPostsResults: Object[];

  readonly dailyPostsSubscription: Subscription;
  measures = [];

  constructor(
    private calculationStore: CalculationStore,
    private router: Router,
    private authStore: AuthStore,
  ) {
    this.dailyPostsLoading = calculationStore.dailyPostsLoading;
    this.dailyPostsSubscription = calculationStore.dailyPosts.subscribe(value => {
      this.measures = [
        {
          name: 'IMC',
          series: [
            {
              name: '2019-09-06',
              value: 21.445729818768108,
            },
            {
              name: '2019-09-07',
              value: 22.291001353045758,
            },
            {
              name: '2019-09-08',
              value: 22.884476637692295,
            },
            {
              name: '2019-09-09',
              value: 22.893175001259184,
            },
            {
              name: '2019-09-10',
              value: 23.794660824609114,
            },
            {
              name: '2019-09-11',
              value: 23.986870469050952,
            },
            {
              name: '2019-09-12',
              value: 23.57546139582314,
            },
            {
              name: '2019-09-13',
              value: 23.73734044215861,
            },
            {
              name: '2019-09-14',
              value: 24.7116090553326,
            },
            {
              name: '2019-09-15',
              value: 24.422734241313105,
            },
            {
              name: '2019-09-16',
              value: 23.71810591132526,
            },
            {
              name: '2019-09-17',
              value: 23.554152608409744,
            },
            {
              name: '2019-09-18',
              value: 22.7816543994937,
            },
            {
              name: '2019-09-19',
              value: 23.306006413627042,
            },
            {
              name: '2019-09-20',
              value: 24.209554984803685,
            },
            {
              name: '2019-09-21',
              value: 23.990189790687698,
            },
            {
              name: '2019-09-22',
              value: 23.661091685009417,
            },
            {
              name: '2019-09-23',
              value: 24.27629770482515,
            },
            {
              name: '2019-09-24',
              value: 24.934699982415683,
            },
            {
              name: '2019-09-25',
              value: 25.89527470635653,
            },
            {
              name: '2019-09-26',
              value: 24.92426898366977,
            },
            {
              name: '2019-09-27',
              value: 24.786001641013097,
            },
            {
              name: '2019-09-28',
              value: 25.422055355780586,
            },
            {
              name: '2019-09-29',
              value: 25.79058209297679,
            },
            {
              name: '2019-09-30',
              value: 26.07781470333826,
            },
            {
              name: '2019-10-01',
              value: 26.224620321592784,
            },
            {
              name: '2019-10-02',
              value: 27.02203655501151,
            },
            {
              name: '2019-10-03',
              value: 26.83140104442331,
            },
            {
              name: '2019-10-04',
              value: 26.118466196279364,
            },
            {
              name: '2019-10-05',
              value: 25.279945616231657,
            },
            {
              name: '2019-10-06',
              value: 25.921643831136453,
            },
            {
              name: '2019-10-08',
              value: 26.08639739028825,
            },
          ],
        },
      ];

      let dates = [
        '2019-09-06',
        '2019-09-07',
        '2019-09-08',
        '2019-09-09',
        '2019-09-10',
        '2019-09-11',
        '2019-09-12',
        '2019-09-13',
        '2019-09-14',
        '2019-09-15',
        '2019-09-16',
        '2019-09-17',
        '2019-09-18',
        '2019-09-19',
        '2019-09-20',
        '2019-09-21',
        '2019-09-22',
        '2019-09-23',
        '2019-09-24',
        '2019-09-25',
        '2019-09-26',
        '2019-09-27',
        '2019-09-28',
        '2019-09-29',
        '2019-09-30',
        '2019-10-01',
        '2019-10-02',
        '2019-10-03',
        '2019-10-04',
        '2019-10-05',
        '2019-10-06',
        '2019-10-08',
      ];
      let data = [
        {
          name: 'IMC',
          min: 15,
          max: 45,
          sign: 1,
        },
        {
          name: 'OS',
          min: 12,
          max: 18,
        },
        {
          name: 'Graisse',
          min: 10,
          max: 50,
          sign: 1,
        },
        {
          name: 'Muscle',
          min: 40,
          max: 75,
        },
        {
          name: 'Eau',
          min: 40,
          max: 65,
        },
        {
          name: 'BMF',
          min: 12,
          max: 20,
        },
        {
          name: 'Poids',
          min: 45,
          max: 113,
          sign: 1,
        },
      ];
      let measures = [];

      let rand = Math.random();

      data.forEach(d => {
        measures.push({
          name: d.name,
          series: [
            {
              name: '2019-09-05',
              value: d.min + rand * (d.max - d.min),
            },
          ],
        });
      });

      dates.forEach((date, j) => {
        rand += Math.random() > 0.5 ? Math.random() : -Math.random();
        data.forEach((d, i) => {
          let last = measures[i].series[j].value;
          let x = 1 - 1 / (d.max - d.min);
          let value = last;

          if (last + x > d.max) {
            value -= x;
          } else if (last - x < d.min) {
            value += x;
          } else {
            value += Math.random() > 0.5 ? x : -x;
          }
          measures[i].series.push({ name: date, value });
        });
      });
      this.measures = measures;
    });
    authStore.user.subscribe((item: User) => {
      if (item.isAdmin) {
        this.router.navigate(['/user']);
      }
    });
  }

  ngOnInit() {
    this.calculationStore.fetchDailyPosts();
  }

  ngOnDestroy(): void {
    this.dailyPostsSubscription.unsubscribe();
  }
}
