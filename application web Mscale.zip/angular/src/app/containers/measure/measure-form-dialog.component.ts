import { Component, Inject, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, FormGroup, AbstractControl } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material';

import { dataIsSuccess, SCENARIO_DEFAULT, SCENARIO_CREATE } from 'app/common';
import { MeasureStore } from 'app/stores';
import { Measure, ErrorMessage, ResponseData } from 'app/models';

@Component({
  selector: 'app-measure-form-dialog',
  templateUrl: './measure-form-dialog.component.html',
})
export class MeasureFormDialogComponent implements OnInit {
  title: string;
  scenario: string;
  form: FormGroup;
  formValue: any;
  model: Measure;
  callback: Function | undefined;

  constructor(
    private formBuilder: FormBuilder,
    private measureStore: MeasureStore,
    @Inject(MAT_DIALOG_DATA) data: any,
  ) {
    this.model = data.model;
    this.title = data.title;
    this.scenario = data.scenario || SCENARIO_DEFAULT;
    this.callback = data.callback;
  }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      bmi: [this.model.bmi, []],
      bmr: [this.model.bmr, []],
      bones: [this.model.bones, []],
      fat: [this.model.fat, []],
      height: [this.model.height, []],
      index: [this.model.index, []],
      water: [this.model.water, []],
      weight: [this.model.weight, []],
      date: [this.model.date, []],
    });
    this.form.valueChanges.forEach(formValue => {
      this.formValue = formValue;
    });
  }

  get modelMerged(): Measure {
    return {
      ...this.model,
      ...this.formValue,
    };
  }

  submit(e: Event): void {
    (() => {
      if (this.scenario === SCENARIO_CREATE) {
        return this.measureStore.create(this.modelMerged);
      } else {
        return this.measureStore.update(this.modelMerged);
      }
    })().subscribe(
      (data: ResponseData) => {
        if (dataIsSuccess(data) || true) {
          this.handleSuccess();
        }
      },
      (errorResp: HttpErrorResponse) => {
        if (errorResp.status === 422) {
          errorResp.error.data.forEach((errorMessage: ErrorMessage) => {
            this.form.get(errorMessage.field).setErrors({
              message: errorMessage.message,
            });
          });
        }
      },
    );
    e.preventDefault();
  }

  private handleSuccess(): void {
    if (this.callback instanceof Function) {
      this.callback();
    }
  }
}
