import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { SortPropDir } from '@swimlane/ngx-datatable';
import { BehaviorSubject } from 'rxjs';

import { objectIsEmpty, SCENARIO_CREATE, SCENARIO_UPDATE } from 'app/common';
import { MeasureStore } from 'app/stores';
import { Measure, MeasureSearch, DatatablePage } from 'app/models';
import { MeasureFormDialogComponent } from './measure-form-dialog.component';

@Component({
  templateUrl: './measure.component.html',
})
export class MeasureComponent implements OnInit {
  readonly loading: BehaviorSubject<boolean>;
  readonly rows: BehaviorSubject<Measure[]>;
  readonly page: BehaviorSubject<DatatablePage>;
  readonly sorts: BehaviorSubject<SortPropDir[]>;
  readonly searchModel: BehaviorSubject<MeasureSearch>;
  currModel: Measure | null = null;

  constructor(private measureStore: MeasureStore, private dialog: MatDialog) {
    this.loading = measureStore.loading;
    this.rows = measureStore.items;
    this.page = measureStore.page;
    this.sorts = measureStore.sorts;
    this.searchModel = measureStore.search;
  }

  ngOnInit(): void {
    this.measureStore.fetchData();
  }

  get hasSearch(): boolean {
    return !objectIsEmpty(this.searchModel.value);
  }

  openMenu(model: Measure): void {
    this.currModel = model;
  }

  setPage(page: DatatablePage): void {
    this.measureStore.page.next(page);
    this.measureStore.fetchData();
  }

  setSorts(sorts: SortPropDir[]): void {
    /**
     * `DataTableComponent` sets offset to 0 in `onColumnSort` method when sort is applied.
     * @see https://github.com/swimlane/ngx-datatable/issues/765
     */
    const page = { ...this.page.value } as DatatablePage;
    page.offset = 0;
    this.measureStore.page.next(page);

    this.measureStore.sorts.next(sorts);
    this.measureStore.fetchData();
  }

  createMeasure(): void {
    const dialogRef = this.openFormDialog({
      title: 'Ajouter une mesure',
      model: new Measure(),
      scenario: SCENARIO_CREATE,
      callback: (): void => {
        this.measureStore.fetchData();
        dialogRef.close();
      },
    });
  }

  viewMeasure(model: Measure): void {
    this.openFormDialog({
      title: 'Afficher une mesure',
      model,
    });
  }

  updateMeasure(model: Measure): void {
    const dialogRef = this.openFormDialog({
      title: 'Modifier patient',
      model,
      scenario: SCENARIO_UPDATE,
      callback: (): void => {
        this.measureStore.fetchData();
        dialogRef.close();
      },
    });
  }

  openFormDialog(data: any): MatDialogRef<MeasureFormDialogComponent> {
    return this.dialog.open(MeasureFormDialogComponent, { data });
  }
}
